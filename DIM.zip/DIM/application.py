from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp

from flask import Flask, jsonify, render_template, request

# Configure application
app = Flask(__name__)

# Ensure responses aren't cached


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


@app.route("/layout", methods=["GET"])
def layout():
    """Layout"""
    if request.method == "GET":
        return render_template("layout.html")


@app.route("/about", methods=["GET"])
def about():
    """About"""
    if request.method == "GET":
        return render_template("about.html")


@app.route("/ourwork", methods=["GET"])
def ourwork():
    """Our Work"""
    if request.method == "GET":
        return render_template("ourwork.html")


@app.route("/team", methods=["GET"])
def team():
    """Meet the Team"""
    if request.method == "GET":
        return render_template("team.html")


@app.route("/opportunities", methods=["GET"])
def opportunities():
    """Opportunities"""
    if request.method == "GET":
        return render_template("opportunities.html")


@app.route("/highered", methods=["GET"])
def highered():
    """Higher Education"""
    if request.method == "GET":
        return render_template("highered.html")


@app.route("/techskills", methods=["GET"])
def techskills():
    """Technology Skills"""
    if request.method == "GET":
        return render_template("techskills.html")


@app.route("/guides", methods=["GET"])
def guides():
    """Guides"""
    if request.method == "GET":
        return render_template("guides.html")


@app.route("/community", methods=["GET"])
def community():
    """Community"""
    if request.method == "GET":
        return render_template("community.html")


@app.route("/testimonies", methods=["GET"])
def testimonies():
    """Testimonies"""
    if request.method == "GET":
        return render_template("testimonies.html")


@app.route("/contactus", methods=["GET"])
def contactus():
    """Contact Us"""
    if request.method == "GET":
        return render_template("contactus.html")

@app.route("/donate", methods=["GET"])
def donate():
    """Doante"""
    if request.method == "GET":
        return render_template("donate.html")


@app.route("/donatetime", methods=["GET"])
def donatetime():
    """Donate Time"""
    if request.method == "GET":
        return render_template("donatetime.html")


@app.route("/donatemoney", methods=["GET"])
def donatemoney():
    """Donate Money"""
    if request.method == "GET":
        return render_template("donatemoney.html")


